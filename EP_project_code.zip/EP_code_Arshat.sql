/*
CREATE TABLE Customers(
customers_id INT,
first_name VARCHAR(16),
last_name VARCHAR(16),
PRIMARY KEY (customers_id)
--make PK to make connection with other tables
);

CREATE TABLE Move_cost(
move_cost_id INT,
move_cost_price DECIMAL(12),
PRIMARY KEY (move_cost_id),
Move_id INT,
FOREIGN KEY (Move_id)
REFERENCES Move(Move_id)
);
CREATE TABLE Schedule(
schedule_id INT,
work_days VARCHAR(255),
weekends VARCHAR(255),
PRIMARY KEY (schedule_id),
Move_id INT,
FOREIGN KEY (Move_id)
REFERENCES Move(Move_id)
);
CREATE TABLE Drivers(
drivers_id INT,
fname VARCHAR(16),
lname VARCHAR(16),
PRIMARY KEY (drivers_id),
customers_id INT,
FOREIGN KEY (customers_id)
REFERENCES Customers(customers_id)
);
CREATE TABLE Trucks(
trucks_id INT,
trucks_model VARCHAR(50),
PRIMARY KEY (trucks_id),
drivers_id INT,
FOREIGN KEY (drivers_id) 
REFERENCES Drivers(drivers_id)
--make connection with drivers id logical
 );
*/

/*
INSERT INTO Customers (customers_id,first_name,last_name)
VALUES (1,'Zakariah','Armstrong'),(2,'Murat','Holmes'),
(3,'Cleveland','Herring'),(4,'Elmer','Michael'),(5,'Ronaldo','Hammond');

INSERT INTO Drivers (drivers_id,fname,lname,customers_id)
VALUES (11,'Oskar','Rodrigues',1),(12,'Ralphy','Bartlett',2),(13,'Jolene','Little',3),
(14,'Shawn','Becker',4),(15,'Mikaela','Cochran',5);

INSERT INTO Trucks(trucks_id,trucks_model,drivers_id)
VALUES (101,'Ford E-Series Cutaway',11),(102,'Ford Transit',12),
(103,'Chevrolet Express',13),(104,'GMC Savana',14),(105,'Mitsubishi FUSO',15);


INSERT INTO Schedule(schedule_id,work_days,weekends,Move_id)
VALUES (1001,'Monday,Friday,Wednesday','Tuesday,Saturday,Sunday,Thursday',121);

INSERT INTO Schedule(schedule_id,work_days,weekends,Move_id)
VALUES (1002,'Sunday,Tuesday,Thursday','Monday,Friday,Wednesday,Saturday',122),
(1003,'Monday,Tuesday,Wednesday','Sunday,Thursday,Friday,Saturday',123),
(1004,'Saturday,Friday,Thursday','Sunday,Wednesday,Monday,Tuesday',124),
(1005,'Saturday,Sunday,Wednesday','Friday,Tuesday,Monday,Thursday',125);

INSERT INTO Move_cost(move_cost_id,move_cost_price,Move_id)
VALUES (1011,100,121),(1012,115,122),(1013,150,123),
(1014,90,124),(1015,95,125);
*/

/*
ALTER TABLE Schedule ADD COLUMN Time time;
ALTER TABLE Schedule DROP COLUMN Time;
ALTER TABLE Trucks ADD COLUMN Year date;
ALTER TABLE Trucks DROP COLUMN year;
ALTER TABLE Customers ALTER first_name SET NOT NULL;
*/

/*
UPDATE Schedule SET work_days='Monday,Tuesday,Sunday' WHERE schedule_id=1003;
UPDATE Customers SET first_name='VLAD' WHERE last_name IN ('Armstrong','Michael');
UPDATE Trucks SET trucks_model='Hino 155 Cab' WHERE trucks_model LIKE 'Ford%';
UPDATE Drivers SET fname='Alan' WHERE LENGTH (fname) BETWEEN 4 AND 6;
*/

/*
DELETE FROM Schedule WHERE work_days LIKE 'Saturday%';
DELETE FROM Move_cost WHERE move_cost_price<105;
DELETE FROM Trucks WHERE drivers_id>=13;
DELETE FROM Drivers WHERE  fname LIKE 'Mik%';
DELETE FROM Customers WHERE first_name='Ronaldo';
*/

/*
SELECT fname,lname,trucks_model
FROM Drivers INNER JOIN Trucks ON Drivers.drivers_id=Trucks.drivers_id
WHERE trucks_model='Ford E-Series Cutaway';

SELECT first_name,last_name,fname,lname
FROM Drivers FULL JOIN Customers ON Drivers.customers_id=Customers.customers_id;

SELECT SUM (move_cost_price) AS total_of_price, move_cost_id FROM Move_cost
GROUP BY move_cost_id;

SELECT customers_id,last_name,first_name,length(last_name) AS l_name
FROM Customers WHERE last_name LIKE 'H%' AND length(last_name)>3;
*/

/*
SELECT customers_id, first_name, last_name
FROM Customers
WHERE last_name=
(SELECT last_name
FROM Customers
WHERE first_name = 'Murat');

SELECT move_cost_id, move_cost_price
FROM Move_cost
WHERE move_cost_price >
(SELECT AVG(move_cost_price)
FROM Move_cost);

SELECT fname
FROM Drivers
WHERE drivers_id >
(SELECT drivers_id
FROM Drivers
WHERE customers_id = 3);
*/



